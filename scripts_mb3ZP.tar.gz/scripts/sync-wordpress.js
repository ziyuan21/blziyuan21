const axios = require('axios');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execSync } = require('child_process');
const TurndownService = require('turndown');
const cheerio = require('cheerio');

const turndown = new TurndownService({ headingStyle: 'atx' });

const ROOT_DIR = path.resolve(__dirname, '..');
const POSTS_DIR = path.join(ROOT_DIR, 'source/_posts');
const IMAGES_DIR = path.join(ROOT_DIR, 'source/images/wp');
const WP_POST_API = 'https://blziyuan21.com/wp-json/wp/v2/posts?status=publish&per_page=10&_fields=id,date,title,slug,categories,content,meta,download_links,full_content_html,link';

if (!fs.existsSync(POSTS_DIR)) fs.mkdirSync(POSTS_DIR, { recursive: true });
if (!fs.existsSync(IMAGES_DIR)) fs.mkdirSync(IMAGES_DIR, { recursive: true });

function generateSlug(title) {
  return crypto.createHash('md5').update(title + Date.now()).digest('hex').slice(0, 8);
}

async function extractAndDownloadImages(contentHtml, slug) {
  const $ = cheerio.load(contentHtml);
  const imageMap = {};

  const images = $('img');
  for (let i = 0; i < images.length; i++) {
    const url = $(images[i]).attr('src');
    if (!url) continue;
    try {
      const ext = path.extname(url).split('?')[0] || '.jpg';
      const filename = `${slug}-${crypto.randomBytes(4).toString('hex')}${ext}`;
      const savePath = path.join(IMAGES_DIR, filename);
      const localUrl = `/images/wp/${filename}`;

      const res = await axios.get(url, { responseType: 'arraybuffer' });
      fs.writeFileSync(savePath, res.data);
      imageMap[url] = localUrl;
      console.log(`🖼 下载图片: ${filename}`);
    } catch (err) {
      console.warn(`⚠️ 图片下载失败: ${url}`);
    }
  }

  return imageMap;
}

async function fetchPosts() {
  const res = await axios.get(WP_POST_API);
  return res.data;
}

async function parseCategoriesAndTags(postUrl) {
  try {
    const res = await axios.get(postUrl);
    const $ = cheerio.load(res.data);

    // 分类提取
    const catElement = $('.article-tags a');
    const categories = [];
    catElement.each((i, el) => {
      const cat = $(el).text().trim();
      if (cat) categories.push(cat);
    });

    // 标签提取（如你主题支持可自行微调 class）
    const tagElements = $('.post-tags a, .article-footer a[href*="/tag/"]');
    const tags = [];
    tagElements.each((i, el) => {
      const tag = $(el).text().trim();
      if (tag) tags.push(tag);
    });

    return { categories, tags };
  } catch (e) {
    console.warn(`⚠️ 无法解析分类/标签: ${postUrl}`);
    return { categories: ['未分类'], tags: [] };
  }
}

async function convertToMarkdown(post) {
  const title = post.title.rendered.replace(/"/g, '\\"');
  const date = post.date;
  const slug = `wp-${post.id}`;


  const permalink = `/posts/${slug}/`;
  const contentHtml = post.full_content_html || post.content.rendered;
  const link = post.link;

  if (!contentHtml || contentHtml.includes('Page Not Found')) return null;

  const { categories, tags } = await parseCategoriesAndTags(link);
  const imageMap = await extractAndDownloadImages(contentHtml, slug);

  let markdownContent = turndown.turndown(contentHtml);
  for (const [remote, local] of Object.entries(imageMap)) {
    markdownContent = markdownContent.replaceAll(remote, local);
  }

  let downloadSection = '';
  if (Array.isArray(post.download_links) && post.download_links.length > 0) {
    downloadSection = '\n\n## 📦 下载链接\n';
    for (const link of post.download_links) {
      downloadSection += `- [${link.label}](${link.url})\n`;
    }
  }

  const frontMatter = `---
title: "${title}"
date: ${date}
slug: ${slug}
permalink: ${permalink}
categories:
${categories.map(c => `  - ${c}`).join('\n')}
tags:
${tags.map(t => `  - ${t}`).join('\n')}
---

${markdownContent}${downloadSection}
`;

  return { slug, content: frontMatter };
}

async function syncPosts() {
  const posts = await fetchPosts();
  let count = 0;

  for (const post of posts) {
    const md = await convertToMarkdown(post);
    if (!md) continue;

    const filename = path.join(POSTS_DIR, `${md.slug}.md`);
    fs.writeFileSync(filename, md.content);
    console.log(`✅ 已保存: ${md.slug}.md`);
    count++;
  }

  if (count === 0) {
    console.log('📭 没有需要同步的文章');
    return;
  }

  execSync('git add source/_posts source/images', { cwd: ROOT_DIR });
  execSync(`git commit -m "sync: update from WordPress ${new Date().toISOString()}" || echo "no changes"`, { cwd: ROOT_DIR });
  execSync('git push origin main', { cwd: ROOT_DIR });
  console.log('🚀 同步并推送到 GitHub 完成');
}

syncPosts().catch(console.error);
